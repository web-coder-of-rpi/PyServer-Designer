---
name: Bug Report
about: Report a bug or error.
---
<!-- Make sure your bug/error report is not already in the issues/PRs. -->
## Bug/Error
<!-- Name your bug/error and explain what is happening. Provide screenshots if possible. -->

## Solution
<!-- This part is optional. -->
