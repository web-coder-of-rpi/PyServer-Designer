---
name: Feature request
about: Ask for a feature to be added.
---
<!-- Make sure your request is not on GitHub yet -->
## Feature/improvement
<!-- Describe your improvement. -->
